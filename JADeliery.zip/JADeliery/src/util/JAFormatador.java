/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

import java.math.BigDecimal;

/**
 *
 * @author jhoua
 */
public class JAFormatador {
    public String converterPontoEmVirgula(String pString){
        String retorno = new String();
        int tamanhoString = pString.length();
        for(int i=0;i<tamanhoString;i++){
            if(pString.charAt(i)=='.'){
                retorno+=',';
            }else{
                retorno+=pString.charAt(i);
            }
        }
        return retorno;
    }
    public String converterVirgulaEmPonto(String pString){
        String retorno = new String();
        int tamanhoString = pString.length();
        for(int i=0;i<tamanhoString;i++){
            if(pString.charAt(i)==','){
                retorno+='.';
            }else{
                retorno+=pString.charAt(i);
            }
        }
        return retorno;
    }
    public String converterBDEmStr(BigDecimal pBigDecimal){
        BigDecimal b = new BigDecimal(""+pBigDecimal+"");
        return b.toPlainString();
    }
}
